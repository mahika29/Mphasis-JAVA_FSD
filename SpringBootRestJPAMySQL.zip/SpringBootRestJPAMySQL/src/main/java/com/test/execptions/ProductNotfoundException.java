package com.test.execptions;

public class ProductNotfoundException extends RuntimeException {
	public ProductNotfoundException(String msg) 
	{
		super(msg);
	}

}
