package com.test.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.test.entity.Product;

import jakarta.transaction.Transactional;

@Transactional
public interface ProductRepository extends JpaRepository<Product, Integer> {
	//custom queries using param method
	
	@Query("select p from Product p where p.name =?1")
	List<Product> getProductsByName(String name);
	
	@Query("select p from Product p where p.qnty = ?1 ")
	List<Product> getProductByQuantity(int qnty);
	
	@Query("select p from Product p where p.name =:name")
	List<Product> getProductByNameQP(@Param("name") String name);
	
	@Query("select p from Product p where p.qnty =:qnty")
	List<Product> getProductByQuantityQP(@Param("qnty") int qnty);
	
	@Query("select p from Product p order by p.name ASC")
	List<Product> getAllProductByNameASC();
	
	

}
